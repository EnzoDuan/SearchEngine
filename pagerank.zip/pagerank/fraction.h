#ifndef Fraction_h
#define Fraction_h

#include <iostream>
#include <cmath>
using namespace std;

class Fraction {
    private :
    int rator;
    int nator;
    
    static int MaxFactor(int a, int b) { // 最大公因数
        if(a == 0 || b == 0) return 1;
        if(abs(a) > abs(b)) { int t = b; b = a; a = t; }
        a = abs(a);
        b = abs(b);
        for(int i = a; i <= b; --i) {
            if(a%i == 0 && b%i == 0)
                return i;
        }
        return 1;
    }
    public :
    Fraction * next;
    Fraction(int rator = 0,int nator = 1) {
        this->rator = rator; this->nator = nator;
        if(this->nator < 0) {
            this->rator *= -1;
            this->nator *= -1;
        }
    }
    friend Fraction operator+(const Fraction &fa, const Fraction &fb) {
        Fraction ft;
        ft.rator = fa.rator * fb.nator + fa.nator * fb.rator;
        ft.nator = fa.nator * fb.nator;
        int tmp = MaxFactor(ft.rator,ft.nator);
        ft.rator /= tmp;
        ft.nator /= tmp;
        return ft;
    }
    friend Fraction operator-(const Fraction &fa, const Fraction &fb) {
        
        Fraction ft;
        ft.rator = fa.rator * fb.nator - fa.nator * fb.rator;
        ft.nator = fa.nator * fb.nator;
        int tmp = MaxFactor(ft.rator,ft.nator);
        ft.rator /= tmp;
        ft.nator /= tmp;
        if(ft.nator < 0) {
            ft.rator *= -1;
            ft.nator *= -1;
        }
        return ft;
    }
    friend Fraction operator*(const Fraction &fa, const Fraction &fb) {
        Fraction ft;
        ft.rator = fa.rator * fb.rator;
        ft.nator = fa.nator * fb.nator;
        int tmp = MaxFactor(ft.rator,ft.nator);
        ft.rator /= tmp;
        ft.nator /= tmp;
        return ft;
    }
    friend Fraction operator/(const Fraction &fa, const Fraction &fb) {
        Fraction ft;
        ft.rator = fa.rator * fb.nator;
        ft.nator = fa.nator * fb.rator;
        int tmp = MaxFactor(ft.rator,ft.nator);
        ft.rator /= tmp;
        ft.nator /= tmp;
        if(ft.nator < 0) {
            ft.rator *= -1;
            ft.nator *= -1;
        }
        return ft;
    }
    friend bool operator>(const Fraction &fa, const Fraction &fb) {
        return fa.rator * fb.nator > fa.nator * fb.rator;
    }
    friend bool operator<(const Fraction &fa, const Fraction &fb) {
        return fa.rator * fb.nator < fa.nator * fb.rator;
    }
    friend bool operator>=(const Fraction &fa, const Fraction &fb) {
        return fa.rator * fb.nator >= fa.nator * fb.rator;
    }
    friend bool operator<=(const Fraction &fa, const Fraction &fb) {
        return fa.rator * fb.nator <= fa.nator * fb.rator;
    }
    friend bool operator==(const Fraction &fa, const Fraction &fb) {
        return abs((fa.nator * fb.nator)/(fa.rator * fb.nator -fa.nator * fb.rator)) > 1000000 ;
    }
    Fraction &operator++() { // 加一个分数单位
        ++rator;
        int tmp = MaxFactor(rator,nator);
        rator /= tmp;
        nator /= tmp;
        return *this;
    }
    Fraction &operator--() { // 减一个分数单位
        --rator;
        int tmp = MaxFactor(rator,nator);
        rator /= tmp;
        nator /= tmp;
        return *this;
    }
    int Getabove(){
        return rator;
    }
    int Getbelow(){
        return nator;
    }
    void Show() const {
        if(nator == 1 || rator == 0) cout << rator << endl;
        else cout << rator << '/' << nator << endl;
    }
};


#endif
