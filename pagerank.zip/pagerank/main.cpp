#include <iostream>
#include <stdio.h>
#include <cstring>
#include "fraction.h"
#include <fstream>
using namespace std;

struct URL{
    Fraction pagerank;
    int degree;//度
    int No;//编号
    URL *next;//链向下一个结点
    URL *link;//链向邻接结点
};


/* 主要实现从爬虫爬取的原文件中获取链接之间的度的关系 */
#define NO_MATCH -1
void SelectURL(char *originFile){

    //originFile为原始文件的路径，从myindex.txt中读取
    FILE *fp = fopen(originFile, "r");
    char targFile[] = "/Users/apple/Desktop/hrel.txt";
    char urlFile[] = "/Users/apple/Desktop/url.txt";
    FILE *fq = fopen(targFile, "a+");
    FILE *fs = fopen(urlFile, "a+");
    
    
    int count = 0;
    char NameOrUrl[20000];
    char ch;
    int Length_of_URL = -1;
    while((ch =fgetc(fp)) != EOF){
        
        /* 匹配出引号“”之间的内容，并计算出根话题的入度 */
        if(ch == 39 || ch == 34){
            if(Length_of_URL == NO_MATCH)
                Length_of_URL++;
            else{
                Length_of_URL = NO_MATCH;
                if(NameOrUrl[0] == 'h'&& NameOrUrl[1] == 't' && NameOrUrl[2] == 't' && NameOrUrl[3] == 'p'){
                    //the sentence between "" is url

                    count++;
                    
                    fprintf(fq, "%s\n", NameOrUrl);

                }
            }
        }
        else{
            if(Length_of_URL != NO_MATCH){
                NameOrUrl[Length_of_URL] = ch;
                Length_of_URL++;
                NameOrUrl[Length_of_URL] = '\0';
            }
        }
    }
    fprintf(fs, "%d\n", count);
    fclose(fp);
    fclose(fq);
    fclose(fs);
}



void load_relations(){
    char buffer[256];
    ifstream in("/Users/apple/Desktop/r.c");
    while (!in.eof() )
    {
        in.getline(buffer,200);
        SelectURL(buffer);
    }
}

void ShowPagerank(){
    
    /* 从文件读取出所需要的pagerank，并输出 */
    
    FILE *f_pgr;
    f_pgr = fopen("/Users/apple/Desktop/pagerank-sub-topic.txt", "r");
    double s[1432], o[1432];
    for(int i = 0; i < 1431; ++i){
        fscanf(f_pgr, "%lf", &s[i]);
        cout << s[i] / 100000<< endl;
    }
    for(int i = 0; i < 1431; ++i){
        fscanf(f_pgr, "%lf", &o[i]);
        cout << o[i] / 100000<< endl;
    }
    
    fclose(f_pgr);
}

void CountPagerank(URL * URL_head, int total){
    
    
    
    URL *p = URL_head;
    double degree[1431];
    for(int i = 0; i < 1431; ++i){
        degree[i] = (double)p->degree;
        p = p->next;
    }
    double pre_p[1431];//记录前一次计算根话题链接的pagerank值
    double pre_q[1431];//记录前一次计算子话题链接的pagerank值
    double cur_p[1431];//记录当前计算根话题链接的pagerank值
    double cur_q[1431];//记录当前计算子话题链接的pagerank值
    
    
    /*
     *由于数据量原因，35w子话题之间链接极少，可以把图近似的看成树来处理
     *由构建的邻接矩阵按照根话题和子话题分块，由分块矩阵进行运算
     *计算找到规律，重复计算直到pagerank值稳定
     */
    
    /* 初始化，pagerank为总数的倒数 */
    for(int i = 0; i < 1431; ++i){
        pre_p[i] = (double)1/total;
        pre_q[i] = (double)1/total;
    }
    
    /* 先进行一次运算 */
    for(int i = 0; i < 1431; ++i){
        
        cur_p[i] = 0.8 * degree[i] * pre_q[i] + 0.2/total;
        
        
        cur_q[i] = 0.8 * pre_p[i]/(degree[i] == 0 ? 1 : degree[i]) + 0.2/total;
        
    }
    
    /* 重复运算80次，经验证，得到的数据已经稳定 */
    for(int j = 0; j < 80; ++j){
        for(int i = 0; i < 1431; ++i){
            
            pre_p[i] = cur_p[i];
            pre_q[i] = cur_q[i];
            
            cur_p[i] = 0.8 * degree[i] * pre_q[i] + 0.2/total;
            
            
            cur_q[i] = 0.8 * pre_p[i]/(degree[i] == 0 ? 1 : degree[i]) + 0.2/total;
            
        }
    }
    
    
    /* 写入文件 */
    FILE *f_pgr = fopen("/Users/apple/Desktop/pagerank-topic.txt", "w");
    
    for(int i = 0; i < 1431; ++i)
        fprintf(f_pgr, "%lf\r\n", cur_p[i] * 100000);
    
    fclose(f_pgr);
    
    f_pgr = fopen("/Users/apple/Desktop/pagerank-sub-topic.txt", "w");
    
    for(int i = 0; i < 1431; ++i)
        fprintf(f_pgr, "%lf\r\n", cur_q[i] * 100000);
    
    fclose(f_pgr);
    
    
    /* 以下注释部分是实现的分数类运算，但运行时效率较慢，放弃不用 */
    
    //    Fraction initial(1, total);
    //    Fraction alpha(4,5);
    //    Fraction _alpha(1,5);
    //    Fraction random = _alpha * initial;
    //    for(t = URL_head; t != NULL; t = t->next)
    //        t->prerank = initial;
    //
    //    for(int i = 0; i < total; ++i){
    //        Fraction *p = new Fraction(0,1);
    //        p->next = NULL;
    //        if(PG_head == NULL)
    //            PG_head = PG_tail = p;
    //        else{
    //            PG_tail->next = p;
    //            PG_tail = p;
    //        }
    //    }
    
    //    URL *p = URL_head;
    //    URL *q;
    //    for(int i = 0; p != NULL && i < 1430; i++, p = p->next){
    //        Fraction zero(0,1);
    //        p->pagerank = zero;
    //
    //        for(q = URL_head;  q->No < 1430; q = q->next)
    //            for(URL *r = q; r != NULL && r->No < i; r = r->link){
    //                if(r->No == i){
    //                    Fraction temp(r->degree,q->degree);
    //                    temp = p->prerank * temp;
    //                    temp = temp * alpha;
    //                    temp = temp + random;
    //                    p->pagerank = p->pagerank + temp;
    //                }
    //            }
    //        p->pagerank.Show();
    //    }
    //    URL *p = URL_head;
    //    Fraction degree[1430];
    //    for(int i = 0; i < 1430; ++i){
    //        Fraction deg(p->degree, 1);
    //        degree[i] = deg;
    //        p = p->next;
    //    }
    //
    //    Fraction pre_p[1430];
    //    Fraction pre_q[1430];
    //    Fraction cur_p[1430];
    //    Fraction cur_q[1430];
    //
    //    for(int i = 0; i < 1430; ++i){
    //        pre_p[i] = initial;
    //        pre_q[i] = initial;
    //    }
    //    cout << "cbhzjnk" << endl;
    //    for(int i = 0; i < 1430; ++i){
    //        Fraction temp = alpha * degree[i];
    //        cout << "yugabwjkne" << endl;
    //        temp = temp*pre_q[i];
    //        cout << "yugabwjkne" << endl;
    //        temp = temp + random;
    //        cout << "yugabwjkne" << endl;
    //        cur_p[i] = temp;
    //        
    //        Fraction t2 = pre_p[i]/degree[i];
    //        t2 = t2 * alpha;
    //        t2 = t2 + random;
    //        cur_q[i] = t2;
    //        cout << "-----------" << endl;
    //    }

}

URL * CreateGragh(URL *URL_head, int &total){
    
    total = -1;
    FILE *fp = fopen("/Users/apple/Desktop/urlnew.txt", "r");
    
    URL_head = NULL;
    URL *tail = NULL;
    URL *t = new URL;
    
    
    while(fscanf(fp, "%d %d", &t->No, &t->degree) != EOF){
        total ++;
        if(URL_head == NULL)
            URL_head = tail = t;
        else{
            tail->next = t;
            tail = t;
        }
        t = new URL;
    }
    fclose(fp);
    
    char str[2000];
    fp = fopen("/Users/apple/Desktop/hrel.txt", "r");
    URL *build_link = URL_head;
    while(build_link->No < 1430){
        
        URL *link_tail = build_link;
        
        for(int i = 0; i < build_link->degree; ++i){
            
            total ++;
            
            t = new URL;
            fscanf(fp, "%s", str);
            t->degree = 1;
            t->No = total;
            t->link = NULL;
            
            link_tail->link = t;
            link_tail = t;
            
            t = new URL;
            t->No = total;
            t->next = NULL;
            t->link = build_link;
            t->degree = 1;
            
            tail->next = t;
            tail = t;
            
        }
        
        build_link = build_link->next;
    }
    fclose(fp);
    
    return URL_head;
}

int main(){
    
    //计数图结点的总数
    int total = -1;
    
    //图的头结点
    URL *URL_head = NULL;
    
    //根据SelectURL（）函数计算出的度，创建图
    URL_head = CreateGragh(URL_head, total);
    
    //根据图计算page rank，并写入文件
    CountPagerank(URL_head, total);
    
    //输出pagerank的值
    ShowPagerank();

    return 0;
}
